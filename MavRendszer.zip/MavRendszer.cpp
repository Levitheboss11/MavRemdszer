//
// Created by levi2 on 2026. 04. 27..
//
#include <iostream>
#include "memtrace.h"
#include "MavRendszer.h"
#include "Szemelyvonat.h"
#include "InterCity.h"

/**
 * @file MavRendszer.cpp
 * @author Tóth Levente István (VK0QG4)
 * @brief A Mavrendszer osztály megvalósítása
 * @date 2026-04-27
 */
MavRendszer::~MavRendszer() {
    // 6.4 Memória felszabadítása
    for (int i = 0; i < vonatDb; ++i) delete vonatok[i];
    delete[] vonatok;

    for (int i = 0; i < jegyDb; ++i) delete jegyek[i];
    delete[] jegyek;
}

void MavRendszer::addVonat(Vonat* v) {
    // 6.1 Dinamikus tömb bővítése algoritmus
    Vonat** ujTomb = new Vonat*[vonatDb + 1];
    for (int i = 0; i < vonatDb; ++i) {
        ujTomb[i] = vonatok[i];
    }
    ujTomb[vonatDb] = v;
    delete[] vonatok;
    vonatok = ujTomb;
    vonatDb++;
}
void MavRendszer::addJegy(Jegy* j) {
    // 6.1 Dinamikus tömb bővítése algoritmus jegyekre
    Jegy** ujTomb = new Jegy*[jegyDb + 1];
    for (int i = 0; i < jegyDb; ++i) {
        ujTomb[i] = jegyek[i];
    }
    ujTomb[jegyDb] = j;
    delete[] jegyek;
    jegyek = ujTomb;
    jegyDb++;
}
void MavRendszer::ujVonat() {
    // Konzolos bekérés helye
    std::cout << "Uj vonat felvetele..." << std::endl;
}

void MavRendszer::jegyKiadas() {
    std::cout << "Jegy kiadasa..." << std::endl;
}

void MavRendszer::menetrendListazas() const {
    for (int i = 0; i < vonatDb; ++i) {
        vonatok[i]->listaz();
    }
}

void MavRendszer::jegyekListazasa() const {
    for (int i = 0; i < jegyDb; ++i) {
        jegyek[i]->listaz();
    }
}

void MavRendszer::betoltes() { /* Fájlkezelés váz */ }
void MavRendszer::mentes() { /* Fájlkezelés váz */ }