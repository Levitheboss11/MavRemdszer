//
// Created by levi2 on 2026. 04. 27..
//
/**
 * @file Vonat.cpp
 * @author Tóth Levente István (VK0QG4)
 * @brief A Vonat osztály megvalósítása
 * @date 2026-04-27
 */
#include "memtrace.h"
#include "Vonat.h"
Vonat::Vonat(int szam, const char* honnan, const char* hova,const  char* ind, const char* erk)
        : vonatszam(szam), honnan(nullptr), hova(nullptr), indulas(nullptr), erkezes(nullptr) {}
Vonat::~Vonat() {

}