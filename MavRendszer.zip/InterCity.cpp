//
// Created by levi2 on 2026. 04. 27..
//
/**
 * @file InterCity.cpp
 * @author Tóth Levente István (VK0QG4)
 * @brief Az Intercity osztály megvalósítása
 * @date 2026-04-27
 */
#include "memtrace.h"
#include "InterCity.h"

InterCity::InterCity(int szam,const char* honnan, const char* hova,const char* ind,const char* erk, int k, int u)
    : Vonat(szam, honnan, hova, ind, erk), kocsikSzama(k), ulesekSzama(u) {

    // Elöször a foglalása a mátrixnak
    ulesRend = new bool*[kocsikSzama];

    // Minden kocsihoz lefoglaljuk az üléseket
    for (int i = 0; i < kocsikSzama; i++) {
        ulesRend[i] = new bool[u];
        for (int j = 0; j < u; j++) {
            // Kezdetben minden ülés szabad ezért az értéke false
            ulesRend[i][j] = false;
        }
    }
}

InterCity::~InterCity() {
    if (ulesRend!=nullptr) {
        // Minden egyes kocsinak a törlése
        for (int i = 0; i < kocsikSzama; ++i) {
            delete[] ulesRend[i];
        }
        // Végül a mutatóknak fő tömbjét is töröljük
        delete[] ulesRend;
    }

}

void InterCity::listaz() const {
    std::cout << "[" << vonatszam << "] IC: " << honnan << " -> " << hova << std::endl;
    std::cout << "   Indulas: " << indulas << " | Erkezes: " << erkezes << std::endl;

    // Szabad helyek számolása
    int szabad = 0;
    for (int i = 0; i < kocsikSzama; ++i) {
        for (int j = 0; j < ulesekSzama; ++j) {
            if (!ulesRend[i][j]) ++szabad;
        }
    }
    std::cout << "   Kocsik: " << kocsikSzama << ", Ulesek/kocsi: " << ulesekSzama
              << " | Szabad helyek: " << szabad << std::endl;
    std::cout << "------------------------------------------" << std::endl;
}
void InterCity::mentes(std::ostream& os) const {
    os << "I;" << vonatszam << ";" << honnan << ";" << hova << ";"
       << indulas << ";" << erkezes << ";"
       << kocsikSzama << ";" << ulesekSzama << std::endl;

}
bool InterCity::helyetFoglal(int& k, int& s) {
    for (int i = 0; i < kocsikSzama; ++i) {
        for (int j = 0; j < ulesekSzama; ++j) {
            if (ulesRend[i][j] == false) { // Találtunk egy szabad helyet
                ulesRend[i][j] = true;    // Lefoglaljuk
                k = i + 1;                // Kocsi száma (1-től indexelve)
                s = j + 1;                // Ülés száma (1-től indexelve)
                return true;
            }
        }
    }
    return false; // Nincs több szabad hely
}
void InterCity::foglalatBeallit(int k, int s) {
    // k-1 és s-1, mert a tömb 0-tól indexelődik, a jegyen meg 1-től van
    int kocsiIdx = k - 1;
    int ulesIdx = s - 1;

    // Ellenőrizzük, hogy érvényes-e a koordináta
    if (kocsiIdx >= 0 && kocsiIdx < kocsikSzama && ulesIdx >= 0 && ulesIdx < ulesekSzama) {
        ulesRend[kocsiIdx][ulesIdx] = true;
    }
}