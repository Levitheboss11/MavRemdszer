//
// Created by levi2 on 2026. 04. 27..
//
/**
 * @file InterCity.cpp
 * @author Tóth Levente István (VK0QG4)
 * @brief Az Intercity osztály megvalósítása
 * @date 2026-04-27
 */
#include "memtrace.h"
#include "InterCity.h"

InterCity::InterCity(int szam,const char* honnan, const char* hova,const char* ind,const char* erk, int k, int u)
    : Vonat(szam, honnan, hova, ind, erk), kocsikSzama(k), ulesekSzama(u) {
    // Itt lesz majd a mátrix foglalás
    ulesRend = nullptr;
}

InterCity::~InterCity() {
    // Itt lesz majd a felszabadítás
}

void InterCity::listaz() const {
    //Itt majd az adatok kiírása lesz
}
void InterCity::mentes(std::ostream& os) const {
    // Itt majd fájlba írás a megadott formátumban (pontosvesszőkkel)
}
bool InterCity::helyetFoglal(int& k, int& s) { return false; } // Helykereső algoritmusnak  helye