//
// Created by levi2 on 2026. 04. 27..
//
/**
 * @file Szemelyvonat.cpp
 * @author Tóth Levente István (VK0QG4)
 * @brief A Szemelyvonat osztály megvalósítása
 * @date 2026-04-27
 */
#include "memtrace.h"
#include "Szemelyvonat.h"
// Szemelyvonat.cpp
Szemelyvonat::Szemelyvonat(int szam, const char* honnan, const char* hova,
                           const char* ind, const char* erk, int kap)
    : Vonat(szam, honnan, hova, ind, erk), osszKapacitas(kap) {
        // A törzs üres marad
}


void Szemelyvonat::listaz() const {
        //Itt majd az adatok kiírása lesz
}
void Szemelyvonat::mentes(std::ostream& os) const {
        // Itt majd fájlba írás a megadott formátumban (pontosvesszőkkel)
}
bool Szemelyvonat::helyetFoglal(int& k, int& u) {
        return true; // Személyvonaton mindig van hely a skeleton (csak most a skeletonban)
}